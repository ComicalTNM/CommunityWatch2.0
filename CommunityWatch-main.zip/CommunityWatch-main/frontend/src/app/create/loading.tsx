// app/loading.tsx
import LoadingSpinner from '@/app/components/LoadingSpinner';

export default function Loading() {
  return <LoadingSpinner />;
}