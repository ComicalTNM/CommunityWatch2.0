export default interface IPost {
    id: Number,
    title: string,
    body: string
}