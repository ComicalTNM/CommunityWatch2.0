export { default as IPost } from "./IPost"

// This file is here so that you can do import more types into  such as the following:
// import { IPost } from "@shared/models"
// vs
// import IPost from "@shared/models/IPost";
