export { default as IPost } from "./models/IPost";

// Not required, but it allows for imports such as:
// import { IPost } from '@shared'