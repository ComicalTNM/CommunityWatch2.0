import IPost from "@shared/models/IPost";

export default function GetPost(): IPost {
    return {
        id: 1,
        body: "",
        title: ""
    }
}