// backend/src/constants.ts
export const DEMO_USER_ID = '60d5ecb74e4d5b2b9c5a7c98';